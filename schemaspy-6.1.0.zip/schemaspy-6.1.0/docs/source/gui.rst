SchemaSpy GUI
-------------

SchemaSpy is a command line tool. If you're more comfortable with the point-and-click approach then try out `Joachim Uhl's <http://www.joachim-uhl.de/>`_ `SchemaSpyGUI <http://schemaspygui.sourceforge.net/>`_.