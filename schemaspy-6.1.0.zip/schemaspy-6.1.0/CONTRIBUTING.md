SchemaSpy Contribution Guidelines

